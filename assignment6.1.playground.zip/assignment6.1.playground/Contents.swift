import UIKit

var greeting = "Hello, playground"

//2
        
//2.1
        
class Product {
    var productID: Int
    var name: String
    var price: Double
    
    init(productID: Int, name: String, price: Double) {
        self.productID = productID
        self.name = name
        self.price = price
    }
}
//2.2
class Cart {
    var cartID: Int
    var items: [Product] = []

    init(cartID: Int) {
        self.cartID = cartID
        self.items = []
    }

    func addProduct(product: Product) {
        items.append(product)
    }

    func removeProduct(productID: Int) {
        items.removeAll { $0.productID == productID }
    }


    func calculateTotal() -> Double {
        return items.reduce(0.0) { $0 + $1.price }
    }
}


class User: Cart {
    var userID: Int
    var username: String

    init(userID: Int, username: String) {
        self.userID = userID
        self.username = username
        super.init(cartID: userID)
    }

    func addProductToCart(product: Product) {
        addProduct(product: product)
    }

    func removeProductFromCart(productID: Int) {
        removeProduct(productID: productID)
    }

    func checkout() -> Double {
        let total = calculateTotal()
        items.removeAll()
        return total
    }
}

//2.4

let product1 = Product(productID: 1, name: "Product 1", price: 1.0)
let product2 = Product(productID: 2, name: "Product 2", price: 2.0)
let product3 = Product(productID: 3, name: "Product 3", price: 3.0)

let user1 = User(userID: 11, username: "User1")
let user2 = User(userID: 22, username: "User2")

user1.addProductToCart(product: product1)
user1.addProductToCart(product: product2)

user2.addProductToCart(product: product2)
user2.addProductToCart(product: product3)

print("\(user1.username)'s Cart costs: \(user1.calculateTotal())$")
print("\(user2.username)'s Cart costs: \(user2.calculateTotal())$")

let user1TotalPrice = user1.checkout()
let user2TotalPrice = user2.checkout()

print("\(user1.username) pays: \(user1TotalPrice)$")
print("\(user2.username) pays: \(user2TotalPrice)$")

user1.items.removeAll()
user2.items.removeAll()

//better understood here, still have some questions. will do some research myself and get back if needed:)

//სუპერ ფენსი კომენტარები....
