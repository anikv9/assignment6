import UIKit

var greeting = "Hello, playground"

//1

//1.1

class Book {
    var bookID: Int
    var title: String
    var author: String
    var isBorrowed: Bool
    var isReturned: Bool
    
    init(bookID: Int, title: String, author: String, isBorrowed: Bool) {
        self.bookID = bookID
        self.title = title
        self.author = author
        self.isBorrowed = true
        self.isReturned = true
    }
    
    func checkIfBorrowed(book: String) -> Bool {
            return isBorrowed
        }
    
    func checkIfReturned(book: String) -> Bool {
        return isReturned
    }
    
    
}

//1.2
class Owner {
    var ownerID: Int
    var name: String
    var borrowedBooks: [String] = []
    
    init(ownerID: Int, name: String, borrowedBooks: [String] = []) {
        self.ownerID = ownerID
        self.name = name
        self.borrowedBooks = borrowedBooks
    }
    
    func isBorrowed (book: String) -> Bool {
        if Book.checkIfBorrowed {
            return false
        } else {
            borrowedBooks.append(book)
            return true
        } // ak raunda!!
    }
    
    func returnBook(book: Book) -> Bool {
        if Book.checkIfBorrowed() {
            return true
            borrowedBooks.remove(at: borrowedBooks.count-1)
        } else {
            return false
        }
    }
    
}
    
let book = Book(bookID: 56, title: "some", author: "something", isBorrowed: true)
print(book.bookID)


//1.3

class Library {
    var books: [Book]
    var owners: [Owner]
    var borrowedBy: Owner?
    
    init(books: [Book] = [], owners: [Owner] = []) {
        self.books = books
        self.owners = owners
    }
        
    func addingBook(book: Book) {
        books.append(book)
    }
    
    func addingOwner(owner: Owner) {
        owners.append(owner)
    }
    
    
    func availableBooks() -> [Book] {
        return books.filter { !isBorrowed(book: $0)}
    }

    func takenBooks() -> [Book] {
        return books.filter { isBorrowed(book: $0) }
    }
    
    func findOwnerByID(ownerID: Int) -> Owner? {
        return owners.first { $0.ownerID == ownerID }
    }

    func booksTakenByOwner(owner: Owner) -> [Book] {
        return books.filter { $0.borrowedBy == owner }
    }

    func takeBook(owner: Owner, book: Book) -> Bool {
        if isBorrowed(book: book) {
            return false
        } else {
            book.borrowedBy = owner
            return true
        }
        
        
//1.4
class Library {
    var books: [Book] = []
    var owners: [Owner] = []

    func addBook(book: Book) {
        books.append(book)
    }

    func addOwner(owner: Owner) {
        owners.append(owner)
    }

    func takeBook(owner: Owner, book: Book) -> Bool {
        if !books.contains(book) {
            return false
        }
        if book.borrowedBy != nil {
            return false
        }
        book.borrowedBy = owner
        return true
    }

    func returnBook(owner: Owner, book: Book) -> Bool {
        if book.borrowedBy != owner {
        return false
    }
    book.borrowedBy = nil
    return true
    }

           
    func displayCheckedOutBooks() {
        let checkedOutBooks = books.filter { $0.borrowedBy != nil
        }
            if checkedOutBooks.isEmpty {
                print("No books are currently checked out.")
            } else {
                print("Books checked out from the library:")
                for book in checkedOutBooks {
                    if let owner = book.borrowedBy {
                        print("\(book.title) by \(book.author) (Borrowed by \(owner.name))")
                    }
                }
            }
        }

        func displayAvailableBooks() {
            let availableBooks = books.filter { $0.borrowedBy == nil }
            if availableBooks.isEmpty {
                print("All books are currently checked out.")
            } else {
                print("Available books in the library:")
                for book in availableBooks {
                    print("\(book.title) by \(book.author)")
                }
            }
        }

          
        func displayCheckedOutBooks(by owner: Owner) {
            let checkedOutBooks = books.filter { $0.borrowedBy == owner }
            if checkedOutBooks.isEmpty {
                print("\(owner.name) has no books checked out.")
            } else {
                print("\(owner.name)'s checked out books:")
                for book in checkedOutBooks {
                    print("\(book.title) by \(book.author)")
                }
                }
            }
        }

        class Book {
            var title: String
            var author: String
            var borrowedBy: Owner?

            init(title: String, author: String) {
                self.title = title
                self.author = author
            }
        }

        class Owner {
            var name: String

            init(name: String) {
                self.name = name
            }
        }

        let myLibrary = Library()


        let book1 = Book(title: "Book 1", author: "Author A")
        let book2 = Book(title: "Book 2", author: "Author B")

        let owner1 = Owner(name: "Owner 1")
        let owner2 = Owner(name: "Owner 2")

       myLibrary.addBook(book: book1)
       myLibrary.addBook(book: book2)
       myLibrary.addOwner(owner: owner1)
       myLibrary.addOwner(owner: owner2)

       myLibrary.takeBook(owner: owner1, book: book1)
       myLibrary.takeBook(owner: owner2, book: book2)
       myLibrary.returnBook(owner: owner1, book: book1)

       myLibrary.displayCheckedOutBooks()

       myLibrary.displayAvailableBooks()

        myLibrary.displayCheckedOutBooks(by: owner1)
        
        //code doesnt launch and keeps sending the same error message. trying to work on the assignment despite this and will come back and check whats wrong later in the course....
        
        
        








    


